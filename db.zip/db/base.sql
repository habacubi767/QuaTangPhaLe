-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: base
-- ------------------------------------------------------
-- Server version	5.7.9

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(1024) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `view` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `thumbnail_base_url` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thumbnail_path` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `author_id` int(11) DEFAULT NULL,
  `updater_id` int(11) DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `published_at` int(11) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_article_author` (`author_id`),
  KEY `fk_article_updater` (`updater_id`),
  KEY `fk_article_category` (`category_id`),
  CONSTRAINT `fk_article_author` FOREIGN KEY (`author_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_article_category` FOREIGN KEY (`category_id`) REFERENCES `article_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_article_updater` FOREIGN KEY (`updater_id`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article`
--

LOCK TABLES `article` WRITE;
/*!40000 ALTER TABLE `article` DISABLE KEYS */;
INSERT INTO `article` VALUES (1,'test-controler-dlf.html','test','<p>fsdfdsfdsfds\r\n</p>\r\n<p><br>\r\n</p>\r\n','',1,'/storage/web/source','1/NMvDjtZ0uMwDHQpXZBjHfMdCx57bRE9n.png',1,1,1,1458925200,1458980592,1458982563),(2,'fsdfdsf-fdsfds-fsdfdsfds-fsdfdsf.html','fdsfsf','<p>fdsfdsfdsffsdf fsdfsd fsdfsd fsd fsdfsdfdsf sfds</p>','',1,'/storage/web/source','1/ClMQ-geBX32naE75Lp2MFG5DbadzTuQn.png',1,1,1,1458925200,1458982273,1458982273);
/*!40000 ALTER TABLE `article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `article_attachment`
--

DROP TABLE IF EXISTS `article_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article_attachment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` int(11) NOT NULL,
  `path` varchar(255) NOT NULL,
  `base_url` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_article_attachment_article` (`article_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article_attachment`
--

LOCK TABLES `article_attachment` WRITE;
/*!40000 ALTER TABLE `article_attachment` DISABLE KEYS */;
INSERT INTO `article_attachment` VALUES (1,1,'1/6-ZeTwfRFoAp8hb6XDWsXbwcz9iZ_qdj.txt','/storage/web/source','text/plain',842,'pts-cs6.txt',1458980592,NULL);
/*!40000 ALTER TABLE `article_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `article_category`
--

DROP TABLE IF EXISTS `article_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(1024) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci,
  `parent_id` int(11) DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_article_category_section` (`parent_id`),
  CONSTRAINT `fk_article_category_section` FOREIGN KEY (`parent_id`) REFERENCES `article_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article_category`
--

LOCK TABLES `article_category` WRITE;
/*!40000 ALTER TABLE `article_category` DISABLE KEYS */;
INSERT INTO `article_category` VALUES (1,'news','News',NULL,NULL,1,1458980210,NULL);
/*!40000 ALTER TABLE `article_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branch`
--

DROP TABLE IF EXISTS `branch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `branch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `address` varchar(250) DEFAULT NULL,
  `owner` varchar(100) DEFAULT NULL,
  `tel` varchar(30) DEFAULT NULL,
  `fax` varchar(30) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `website` varchar(50) DEFAULT NULL,
  `hotline` varchar(30) DEFAULT NULL,
  `is_master` int(1) DEFAULT '0',
  `parent_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branch`
--

LOCK TABLES `branch` WRITE;
/*!40000 ALTER TABLE `branch` DISABLE KEYS */;
INSERT INTO `branch` VALUES (44,'5959','','','','','','','',NULL,NULL),(45,'5959','','','','','','','',NULL,NULL),(46,'cong ty qua tang pha le','1b ly chinh thang, quan 3, ho chi minh','','+84963556467','','','','',NULL,NULL),(47,'f dsf fs sfsd','','','','','','','',NULL,NULL),(48,'f dsf fs sfsd','','','','','','','',NULL,NULL),(49,'ssadsadsa22132142121421','','','','','','','',NULL,NULL);
/*!40000 ALTER TABLE `branch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `card_checkstore`
--

DROP TABLE IF EXISTS `card_checkstore`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `card_checkstore` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(30) DEFAULT NULL,
  `employee_id` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `note` varchar(500) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `card_checkstore`
--

LOCK TABLES `card_checkstore` WRITE;
/*!40000 ALTER TABLE `card_checkstore` DISABLE KEYS */;
/*!40000 ALTER TABLE `card_checkstore` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `card_checkstore_detail`
--

DROP TABLE IF EXISTS `card_checkstore_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `card_checkstore_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_code` varchar(50) DEFAULT NULL,
  `product_name` varchar(250) DEFAULT NULL,
  `product_current_amount` int(11) DEFAULT NULL,
  `product_real_amount` int(11) DEFAULT NULL,
  `product_difference_amount` int(11) DEFAULT NULL,
  `reason` varchar(500) DEFAULT NULL,
  `card_checkstore_id` int(11) DEFAULT NULL,
  `cost_difference` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `card_checkstore_detail`
--

LOCK TABLES `card_checkstore_detail` WRITE;
/*!40000 ALTER TABLE `card_checkstore_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `card_checkstore_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `card_import`
--

DROP TABLE IF EXISTS `card_import`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `card_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) DEFAULT NULL,
  `total` decimal(10,0) DEFAULT NULL,
  `discount` decimal(10,0) DEFAULT NULL,
  `discount_type` int(1) DEFAULT NULL,
  `other_fee` decimal(10,0) DEFAULT NULL,
  `total_pay` decimal(10,0) DEFAULT NULL,
  `prepay` decimal(10,0) DEFAULT NULL,
  `remain_fee` decimal(10,0) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `employee_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL,
  `note` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `card_import`
--

LOCK TABLES `card_import` WRITE;
/*!40000 ALTER TABLE `card_import` DISABLE KEYS */;
/*!40000 ALTER TABLE `card_import` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `card_import_detail`
--

DROP TABLE IF EXISTS `card_import_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `card_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_code` varchar(50) DEFAULT NULL,
  `product_name` varchar(250) DEFAULT NULL,
  `product_price` decimal(10,0) DEFAULT NULL,
  `product_amount` int(11) DEFAULT NULL,
  `total` decimal(10,0) DEFAULT NULL,
  `card_import_id` int(11) DEFAULT NULL,
  `note` varchar(500) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `card_import_detail`
--

LOCK TABLES `card_import_detail` WRITE;
/*!40000 ALTER TABLE `card_import_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `card_import_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `card_request`
--

DROP TABLE IF EXISTS `card_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `card_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(30) DEFAULT NULL,
  `total` decimal(10,0) DEFAULT NULL,
  `note` varchar(500) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `employee_id` int(11) DEFAULT NULL,
  `provider_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `card_request`
--

LOCK TABLES `card_request` WRITE;
/*!40000 ALTER TABLE `card_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `card_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `card_request_detail`
--

DROP TABLE IF EXISTS `card_request_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `card_request_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `product_code` varchar(50) DEFAULT NULL,
  `product_name` varchar(250) DEFAULT NULL,
  `product_price` decimal(10,0) DEFAULT NULL,
  `product_amount` int(11) DEFAULT NULL,
  `total` decimal(10,0) DEFAULT NULL,
  `card_request_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `card_request_detail`
--

LOCK TABLES `card_request_detail` WRITE;
/*!40000 ALTER TABLE `card_request_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `card_request_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `card_transfer`
--

DROP TABLE IF EXISTS `card_transfer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `card_transfer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(30) DEFAULT NULL,
  `employeed_id` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `store_out` int(11) DEFAULT NULL,
  `store_in` int(11) DEFAULT NULL,
  `employee_id_in` int(11) DEFAULT NULL,
  `date_received` datetime DEFAULT NULL,
  `note` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `card_transfer`
--

LOCK TABLES `card_transfer` WRITE;
/*!40000 ALTER TABLE `card_transfer` DISABLE KEYS */;
/*!40000 ALTER TABLE `card_transfer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `card_transfer_detail`
--

DROP TABLE IF EXISTS `card_transfer_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `card_transfer_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_code` varchar(50) DEFAULT NULL,
  `product_name` varchar(250) DEFAULT NULL,
  `product_amount` int(11) DEFAULT NULL,
  `note` varchar(500) DEFAULT NULL,
  `card_transfer_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `card_transfer_detail`
--

LOCK TABLES `card_transfer_detail` WRITE;
/*!40000 ALTER TABLE `card_transfer_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `card_transfer_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `note` varchar(500) DEFAULT NULL,
  `customer_type` int(11) DEFAULT NULL,
  `is_anonymous` int(1) DEFAULT NULL,
  `gender` int(1) DEFAULT NULL,
  `birth_day` date DEFAULT NULL,
  `province_id` int(11) DEFAULT NULL,
  `district_id` int(11) DEFAULT NULL,
  `company` varchar(250) DEFAULT NULL,
  `tax_code` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_group`
--

DROP TABLE IF EXISTS `customer_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(30) DEFAULT NULL,
  `name` varchar(150) DEFAULT NULL,
  `note` varchar(500) DEFAULT NULL,
  `is_active` int(1) DEFAULT NULL,
  `discount` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_group`
--

LOCK TABLES `customer_group` WRITE;
/*!40000 ALTER TABLE `customer_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `department` (
  `id` varchar(10) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `is_active` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `district`
--

DROP TABLE IF EXISTS `district`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `district` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `province_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `district`
--

LOCK TABLES `district` WRITE;
/*!40000 ALTER TABLE `district` DISABLE KEYS */;
/*!40000 ALTER TABLE `district` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_storage_item`
--

DROP TABLE IF EXISTS `file_storage_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_storage_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `component` varchar(255) NOT NULL,
  `base_url` varchar(1024) NOT NULL,
  `path` varchar(1024) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `upload_ip` varchar(15) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_storage_item`
--

LOCK TABLES `file_storage_item` WRITE;
/*!40000 ALTER TABLE `file_storage_item` DISABLE KEYS */;
INSERT INTO `file_storage_item` VALUES (1,'fileStorage','/storage/web/source','1/NMvDjtZ0uMwDHQpXZBjHfMdCx57bRE9n.png','image/png',18758,'NMvDjtZ0uMwDHQpXZBjHfMdCx57bRE9n','127.0.0.1',1458980551),(2,'fileStorage','/storage/web/source','1/6-ZeTwfRFoAp8hb6XDWsXbwcz9iZ_qdj.txt','text/plain',842,'6-ZeTwfRFoAp8hb6XDWsXbwcz9iZ_qdj','127.0.0.1',1458980556),(3,'fileStorage','/storage/web/source','1/P0Qu6_3e_fw6wPo0CgSXIRI1S_PxK7bq.png','image/png',4814,'P0Qu6_3e_fw6wPo0CgSXIRI1S_PxK7bq','127.0.0.1',1458981543),(4,'fileStorage','/storage/web/source','1/ClMQ-geBX32naE75Lp2MFG5DbadzTuQn.png','image/png',18758,'ClMQ-geBX32naE75Lp2MFG5DbadzTuQn','127.0.0.1',1458982264);
/*!40000 ALTER TABLE `file_storage_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `i18n_message`
--

DROP TABLE IF EXISTS `i18n_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `i18n_message` (
  `id` int(11) NOT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `translation` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`,`language`),
  CONSTRAINT `fk_i18n_message_source_message` FOREIGN KEY (`id`) REFERENCES `i18n_source_message` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `i18n_message`
--

LOCK TABLES `i18n_message` WRITE;
/*!40000 ALTER TABLE `i18n_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `i18n_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `i18n_source_message`
--

DROP TABLE IF EXISTS `i18n_source_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `i18n_source_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `i18n_source_message`
--

LOCK TABLES `i18n_source_message` WRITE;
/*!40000 ALTER TABLE `i18n_source_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `i18n_source_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `key_storage_item`
--

DROP TABLE IF EXISTS `key_storage_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `key_storage_item` (
  `key` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `updated_at` int(11) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`key`),
  UNIQUE KEY `idx_key_storage_item_key` (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `key_storage_item`
--

LOCK TABLES `key_storage_item` WRITE;
/*!40000 ALTER TABLE `key_storage_item` DISABLE KEYS */;
INSERT INTO `key_storage_item` VALUES ('backend.theme-skin','skin-blue','skin-blue, skin-black, skin-purple, skin-green, skin-red, skin-yellow',1458980810,NULL),('backend.layout-fixed','0',NULL,1458980810,NULL),('backend.layout-boxed','0',NULL,1458980810,NULL),('backend.layout-collapsed-sidebar','0',NULL,1458980810,NULL),('frontend.maintenance','enabled','true',1458980810,NULL);
/*!40000 ALTER TABLE `key_storage_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(30) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `tel` varchar(50) DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL,
  `employee_id` int(11) DEFAULT NULL,
  `tel_employee` varchar(30) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `source_order` int(1) DEFAULT NULL,
  `ship_method` int(11) DEFAULT NULL,
  `total` decimal(10,0) DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `discount_type` int(11) DEFAULT NULL,
  `ship_cost` decimal(10,0) DEFAULT NULL,
  `type_payment` int(11) DEFAULT NULL,
  `vat` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `customer_pay` decimal(10,0) DEFAULT NULL,
  `customer_receive` decimal(10,0) DEFAULT NULL,
  `customer_own` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_detail`
--

DROP TABLE IF EXISTS `order_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `product_code` varchar(50) DEFAULT NULL,
  `product_name` varchar(250) DEFAULT NULL,
  `product_price` decimal(10,0) DEFAULT NULL,
  `product_amout` int(11) DEFAULT NULL,
  `discount` decimal(10,0) DEFAULT NULL,
  `note` varchar(500) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_detail`
--

LOCK TABLES `order_detail` WRITE;
/*!40000 ALTER TABLE `order_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page`
--

DROP TABLE IF EXISTS `page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(2048) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `view` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` smallint(6) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page`
--

LOCK TABLES `page` WRITE;
/*!40000 ALTER TABLE `page` DISABLE KEYS */;
INSERT INTO `page` VALUES (1,'about','About','Lorem ipsum dolor sit amet, consectetur adipiscing elit.',NULL,1,1458980210,1458980210),(2,'czxczxcxzcxzcxzc','cxzczxczxczx','<p>xzczxczxcxzczxc</p>','',1,1458982304,1458982304);
/*!40000 ALTER TABLE `page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_attribute`
--

DROP TABLE IF EXISTS `product_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_attribute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `value` varchar(250) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_attribute`
--

LOCK TABLES `product_attribute` WRITE;
/*!40000 ALTER TABLE `product_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_category`
--

DROP TABLE IF EXISTS `product_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `description` text,
  `parent_id` int(11) DEFAULT NULL,
  `image` varchar(250) DEFAULT NULL,
  `is_active` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_category`
--

LOCK TABLES `product_category` WRITE;
/*!40000 ALTER TABLE `product_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_in_store`
--

DROP TABLE IF EXISTS `product_in_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_in_store` (
  `store_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `amount` int(11) DEFAULT NULL,
  `min` int(11) DEFAULT NULL,
  `max` int(11) DEFAULT NULL,
  PRIMARY KEY (`store_id`,`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_in_store`
--

LOCK TABLES `product_in_store` WRITE;
/*!40000 ALTER TABLE `product_in_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_in_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotion`
--

DROP TABLE IF EXISTS `promotion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promotion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `code` varchar(30) DEFAULT NULL,
  `date_start` datetime DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `amount` int(11) DEFAULT '-1',
  `employee_id` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `cost_min` decimal(10,0) DEFAULT NULL,
  `cost_max` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotion`
--

LOCK TABLES `promotion` WRITE;
/*!40000 ALTER TABLE `promotion` DISABLE KEYS */;
/*!40000 ALTER TABLE `promotion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotion_customer_group`
--

DROP TABLE IF EXISTS `promotion_customer_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promotion_customer_group` (
  `promotion_id` int(11) NOT NULL,
  `customer_group_id` int(11) NOT NULL,
  PRIMARY KEY (`promotion_id`,`customer_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotion_customer_group`
--

LOCK TABLES `promotion_customer_group` WRITE;
/*!40000 ALTER TABLE `promotion_customer_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `promotion_customer_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotion_product`
--

DROP TABLE IF EXISTS `promotion_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promotion_product` (
  `promotion_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`promotion_id`,`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotion_product`
--

LOCK TABLES `promotion_product` WRITE;
/*!40000 ALTER TABLE `promotion_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `promotion_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotion_store`
--

DROP TABLE IF EXISTS `promotion_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promotion_store` (
  `store_id` int(11) NOT NULL,
  `promotion_id` int(11) NOT NULL,
  PRIMARY KEY (`store_id`,`promotion_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotion_store`
--

LOCK TABLES `promotion_store` WRITE;
/*!40000 ALTER TABLE `promotion_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `promotion_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provider`
--

DROP TABLE IF EXISTS `provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `provider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL,
  `tel` varchar(50) DEFAULT NULL,
  `fax` varchar(50) DEFAULT NULL,
  `owner` varchar(250) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `company_name` varchar(250) DEFAULT NULL,
  `website` varchar(50) DEFAULT NULL,
  `province_id` int(11) DEFAULT NULL,
  `district_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provider`
--

LOCK TABLES `provider` WRITE;
/*!40000 ALTER TABLE `provider` DISABLE KEYS */;
/*!40000 ALTER TABLE `provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `province`
--

DROP TABLE IF EXISTS `province`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `province` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `code` varchar(10) DEFAULT NULL,
  `zone` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `province`
--

LOCK TABLES `province` WRITE;
/*!40000 ALTER TABLE `province` DISABLE KEYS */;
/*!40000 ALTER TABLE `province` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rbac_auth_assignment`
--

DROP TABLE IF EXISTS `rbac_auth_assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rbac_auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  CONSTRAINT `rbac_auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `rbac_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rbac_auth_assignment`
--

LOCK TABLES `rbac_auth_assignment` WRITE;
/*!40000 ALTER TABLE `rbac_auth_assignment` DISABLE KEYS */;
INSERT INTO `rbac_auth_assignment` VALUES ('administrator','1',1458980214),('manager','2',1458980214),('user','3',1458980214);
/*!40000 ALTER TABLE `rbac_auth_assignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rbac_auth_item`
--

DROP TABLE IF EXISTS `rbac_auth_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rbac_auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx-auth_item-type` (`type`),
  CONSTRAINT `rbac_auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `rbac_auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rbac_auth_item`
--

LOCK TABLES `rbac_auth_item` WRITE;
/*!40000 ALTER TABLE `rbac_auth_item` DISABLE KEYS */;
INSERT INTO `rbac_auth_item` VALUES ('administrator',1,NULL,NULL,NULL,1458980214,1458980214),('editOwnModel',2,NULL,'ownModelRule',NULL,1458980214,1458980214),('loginToBackend',2,NULL,NULL,NULL,1458980214,1458980214),('manager',1,NULL,NULL,NULL,1458980213,1458980213),('user',1,NULL,NULL,NULL,1458980213,1458980213);
/*!40000 ALTER TABLE `rbac_auth_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rbac_auth_item_child`
--

DROP TABLE IF EXISTS `rbac_auth_item_child`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rbac_auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`),
  CONSTRAINT `rbac_auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `rbac_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `rbac_auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `rbac_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rbac_auth_item_child`
--

LOCK TABLES `rbac_auth_item_child` WRITE;
/*!40000 ALTER TABLE `rbac_auth_item_child` DISABLE KEYS */;
INSERT INTO `rbac_auth_item_child` VALUES ('user','editOwnModel'),('manager','loginToBackend'),('administrator','manager'),('manager','user');
/*!40000 ALTER TABLE `rbac_auth_item_child` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rbac_auth_rule`
--

DROP TABLE IF EXISTS `rbac_auth_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rbac_auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rbac_auth_rule`
--

LOCK TABLES `rbac_auth_rule` WRITE;
/*!40000 ALTER TABLE `rbac_auth_rule` DISABLE KEYS */;
INSERT INTO `rbac_auth_rule` VALUES ('ownModelRule','O:29:\"common\\rbac\\rule\\OwnModelRule\":3:{s:4:\"name\";s:12:\"ownModelRule\";s:9:\"createdAt\";i:1458980214;s:9:\"updatedAt\";i:1458980214;}',1458980214,1458980214);
/*!40000 ALTER TABLE `rbac_auth_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `store`
--

DROP TABLE IF EXISTS `store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL,
  `tel` varchar(30) DEFAULT NULL,
  `manager_id` int(11) DEFAULT NULL,
  `is_active` int(1) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `code` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store`
--

LOCK TABLES `store` WRITE;
/*!40000 ALTER TABLE `store` DISABLE KEYS */;
/*!40000 ALTER TABLE `store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_db_migration`
--

DROP TABLE IF EXISTS `system_db_migration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_db_migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_db_migration`
--

LOCK TABLES `system_db_migration` WRITE;
/*!40000 ALTER TABLE `system_db_migration` DISABLE KEYS */;
INSERT INTO `system_db_migration` VALUES ('m000000_000000_base',1458980176),('m140703_123000_user',1458980183),('m140703_123055_log',1458980184),('m140703_123104_page',1458980184),('m140703_123803_article',1458980193),('m140703_123813_rbac',1458980197),('m140709_173306_widget_menu',1458980198),('m140709_173333_widget_text',1458980199),('m140712_123329_widget_carousel',1458980202),('m140805_084745_key_storage_item',1458980202),('m141012_101932_i18n_tables',1458980206),('m150318_213934_file_storage_item',1458980206),('m150414_195800_timeline_event',1458980207),('m150725_192740_seed_data',1458980210),('m150929_074021_article_attachment_order',1458980210),('m160203_095604_user_token',1458980210);
/*!40000 ALTER TABLE `system_db_migration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_log`
--

DROP TABLE IF EXISTS `system_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `level` int(11) DEFAULT NULL,
  `category` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `log_time` double DEFAULT NULL,
  `prefix` text COLLATE utf8_unicode_ci,
  `message` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `idx_log_level` (`level`),
  KEY `idx_log_category` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_log`
--

LOCK TABLES `system_log` WRITE;
/*!40000 ALTER TABLE `system_log` DISABLE KEYS */;
INSERT INTO `system_log` VALUES (1,1,'yii\\base\\InvalidParamException',1458981596.1694,'[frontend][/article/test-controler-dlf.html]','exception \'yii\\base\\InvalidParamException\' with message \'The view file does not exist: D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\frontend\\views\\article\\32.php\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php:226\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(149): yii\\base\\View->renderFile(\'D:\\\\Working\\\\Me\\\\i...\', Array, Object(frontend\\controllers\\ArticleController))\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(377): yii\\base\\View->render(\'32\', Array, Object(frontend\\controllers\\ArticleController))\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\frontend\\controllers\\ArticleController.php(43): yii\\base\\Controller->render(\'32\', Array)\n#3 [internal function]: frontend\\controllers\\ArticleController->actionView(\'test-controler-...\')\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'view\', Array)\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'article/view\', Array)\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#10 {main}'),(2,1,'yii\\base\\InvalidParamException',1458982052.7697,'[frontend][/article/test-controler-dlf.html]','exception \'yii\\base\\InvalidParamException\' with message \'The view file does not exist: D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\frontend\\views\\article\\32.php\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php:226\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(149): yii\\base\\View->renderFile(\'D:\\\\Working\\\\Me\\\\i...\', Array, Object(frontend\\controllers\\ArticleController))\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(377): yii\\base\\View->render(\'32\', Array, Object(frontend\\controllers\\ArticleController))\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\frontend\\controllers\\ArticleController.php(43): yii\\base\\Controller->render(\'32\', Array)\n#3 [internal function]: frontend\\controllers\\ArticleController->actionView(\'test-controler-...\')\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'view\', Array)\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'article/view\', Array)\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#10 {main}'),(3,1,'yii\\base\\UnknownClassException',1459086530.9475,'[backend][/admin/branch/index]','exception \'yii\\base\\UnknownClassException\' with message \'Unable to find \'backend\\controllers\\BranchController\' in file: D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend/controllers/BranchController.php. Namespace missing?\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\BaseYii.php:291\nStack trace:\n#0 [internal function]: yii\\BaseYii::autoload(\'backend\\\\control...\')\n#1 [internal function]: spl_autoload_call(\'backend\\\\control...\')\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(562): class_exists(\'backend\\\\control...\')\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(520): yii\\base\\Module->createControllerByID(\'branch\')\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(448): yii\\base\\Module->createController(\'branch/index\')\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/index\', Array)\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#8 {main}'),(4,1,'yii\\base\\UnknownClassException',1459086531.2839,'[backend][/admin/branch/sizzle.min.map]','exception \'yii\\base\\UnknownClassException\' with message \'Unable to find \'backend\\controllers\\BranchController\' in file: D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend/controllers/BranchController.php. Namespace missing?\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\BaseYii.php:291\nStack trace:\n#0 [internal function]: yii\\BaseYii::autoload(\'backend\\\\control...\')\n#1 [internal function]: spl_autoload_call(\'backend\\\\control...\')\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(562): class_exists(\'backend\\\\control...\')\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(520): yii\\base\\Module->createControllerByID(\'branch\')\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(448): yii\\base\\Module->createController(\'branch/sizzle.m...\')\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/sizzle.m...\', Array)\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#8 {main}'),(5,1,'yii\\base\\InvalidParamException',1459087773.0513,'[backend][/admin/branch/create]','exception \'yii\\base\\InvalidParamException\' with message \'The view file does not exist: D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\views\\layouts\\.php\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php:226\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(392): yii\\base\\View->renderFile(\'D:\\\\Working\\\\Me\\\\i...\', Array, Object(backend\\controllers\\BranchController))\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(378): yii\\base\\Controller->renderContent(\'<div class=\"bra...\')\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(72): yii\\base\\Controller->render(\'create\', Array)\n#3 [internal function]: backend\\controllers\\BranchController->actionCreate()\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'create\', Array)\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/create\', Array)\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#10 {main}'),(6,1,'yii\\base\\ErrorException:4',1459089298.9507,'[backend][/admin/branch/]','exception \'yii\\base\\ErrorException\' with message \'syntax error, unexpected \'{\'\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php:79\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(562): ::spl_autoload_call()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(562): ::class_exists()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(520): yii\\base\\Module->createControllerByID()\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(448): yii\\base\\Module->createController()\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction()\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest()\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#7 {main}'),(7,1,'yii\\base\\ErrorException:4',1459089299.2593,'[backend][/admin/branch/sizzle.min.map]','exception \'yii\\base\\ErrorException\' with message \'syntax error, unexpected \'{\'\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php:79\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(562): ::spl_autoload_call()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(562): ::class_exists()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(520): yii\\base\\Module->createControllerByID()\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(448): yii\\base\\Module->createController()\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction()\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest()\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#7 {main}'),(8,1,'yii\\base\\ErrorException:4',1459089300.4296,'[backend][/admin/branch/]','exception \'yii\\base\\ErrorException\' with message \'syntax error, unexpected \'{\'\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php:79\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(562): ::spl_autoload_call()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(562): ::class_exists()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(520): yii\\base\\Module->createControllerByID()\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(448): yii\\base\\Module->createController()\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction()\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest()\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#7 {main}'),(9,1,'yii\\base\\ErrorException:4',1459089300.6693,'[backend][/admin/branch/sizzle.min.map]','exception \'yii\\base\\ErrorException\' with message \'syntax error, unexpected \'{\'\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php:79\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(562): ::spl_autoload_call()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(562): ::class_exists()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(520): yii\\base\\Module->createControllerByID()\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(448): yii\\base\\Module->createController()\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction()\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest()\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#7 {main}'),(10,1,'yii\\base\\ErrorException:1',1459089682.195,'[backend][/admin/branch/view?id=4]','exception \'yii\\base\\ErrorException\' with message \'Class \'kartik\\widgets\\Growl\' not found\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\views\\layouts\\main.php:8\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(247): yii\\base\\View->renderPhpFile()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(392): yii\\base\\View->renderFile()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(378): yii\\base\\Controller->renderContent()\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(53): yii\\base\\Controller->render()\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): backend\\controllers\\BranchController->actionView()\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): ::call_user_func_array:{D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php:55}()\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams()\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction()\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction()\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest()\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#11 {main}'),(11,1,'yii\\base\\ErrorException:4',1459090498.906,'[backend][/admin/branch/]','exception \'yii\\base\\ErrorException\' with message \'syntax error, unexpected \'var\' (T_VAR)\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\views\\layouts\\main.php:35\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(392): yii\\base\\View->renderFile()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(378): yii\\base\\Controller->renderContent()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(41): yii\\base\\Controller->render()\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): backend\\controllers\\BranchController->actionIndex()\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): ::call_user_func_array:{D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php:55}()\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams()\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction()\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction()\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest()\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#10 {main}'),(12,1,'yii\\base\\ErrorException:8',1459090532.5923,'[backend][/admin/branch/]','exception \'yii\\base\\ErrorException\' with message \'Undefined variable: size\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\views\\layouts\\main.php:48\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(247): yii\\base\\View->renderPhpFile()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(392): yii\\base\\View->renderFile()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(378): yii\\base\\Controller->renderContent()\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(41): yii\\base\\Controller->render()\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): backend\\controllers\\BranchController->actionIndex()\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): ::call_user_func_array:{D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php:55}()\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams()\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction()\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction()\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest()\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#11 {main}'),(13,1,'yii\\base\\ErrorException:1',1459090554.3296,'[backend][/admin/branch/]','exception \'yii\\base\\ErrorException\' with message \'Class \'View\' not found\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\views\\layouts\\main.php:68\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(247): yii\\base\\View->renderPhpFile()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(392): yii\\base\\View->renderFile()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(378): yii\\base\\Controller->renderContent()\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(41): yii\\base\\Controller->render()\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): backend\\controllers\\BranchController->actionIndex()\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): ::call_user_func_array:{D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php:55}()\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams()\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction()\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction()\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest()\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#11 {main}'),(14,1,'yii\\db\\Exception',1459157709.4158,'[backend][/admin/branch/create]','exception \'PDOException\' with message \'SQLSTATE[HY000]: General error: 1366 Incorrect string value: \'\\xC4\\x91sfd ...\' for column \'name\' at row 1\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Command.php:784\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Command.php(784): PDOStatement->execute()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Schema.php(448): yii\\db\\Command->execute()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(457): yii\\db\\Schema->insert(\'branch\', Array)\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(427): yii\\db\\ActiveRecord->insertInternal(NULL)\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\BaseActiveRecord.php(593): yii\\db\\ActiveRecord->insert(true, NULL)\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(77): yii\\db\\BaseActiveRecord->save()\n#6 [internal function]: backend\\controllers\\BranchController->actionCreate()\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'create\', Array)\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/create\', Array)\n#11 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#12 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#13 {main}\n\nNext exception \'yii\\db\\Exception\' with message \'SQLSTATE[HY000]: General error: 1366 Incorrect string value: \'\\xC4\\x91sfd ...\' for column \'name\' at row 1\nThe SQL being executed was: INSERT INTO `branch` (`name`, `address`, `owner`, `tel`, `fax`, `email`, `website`, `hotline`, `is_master`, `parent_id`) VALUES (\'fdsfdsf fsđsfd fds fsdf fsdf\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', NULL, NULL)\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Schema.php:628\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Command.php(794): yii\\db\\Schema->convertException(Object(PDOException), \'INSERT INTO `br...\')\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Schema.php(448): yii\\db\\Command->execute()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(457): yii\\db\\Schema->insert(\'branch\', Array)\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(427): yii\\db\\ActiveRecord->insertInternal(NULL)\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\BaseActiveRecord.php(593): yii\\db\\ActiveRecord->insert(true, NULL)\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(77): yii\\db\\BaseActiveRecord->save()\n#6 [internal function]: backend\\controllers\\BranchController->actionCreate()\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'create\', Array)\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/create\', Array)\n#11 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#12 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#13 {main}\r\nAdditional Information:\r\nArray\n(\n    [0] => HY000\n    [1] => 1366\n    [2] => Incorrect string value: \'\\xC4\\x91sfd ...\' for column \'name\' at row 1\n)\n'),(15,1,'yii\\db\\Exception',1459157709.7003,'[backend][/admin/branch/create]','exception \'PDOException\' with message \'SQLSTATE[HY000]: General error: 1366 Incorrect string value: \'\\xC4\\x91sfd ...\' for column \'name\' at row 1\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Command.php:784\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Command.php(784): PDOStatement->execute()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Schema.php(448): yii\\db\\Command->execute()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(457): yii\\db\\Schema->insert(\'branch\', Array)\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(427): yii\\db\\ActiveRecord->insertInternal(NULL)\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\BaseActiveRecord.php(593): yii\\db\\ActiveRecord->insert(true, NULL)\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(77): yii\\db\\BaseActiveRecord->save()\n#6 [internal function]: backend\\controllers\\BranchController->actionCreate()\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'create\', Array)\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/create\', Array)\n#11 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#12 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#13 {main}\n\nNext exception \'yii\\db\\Exception\' with message \'SQLSTATE[HY000]: General error: 1366 Incorrect string value: \'\\xC4\\x91sfd ...\' for column \'name\' at row 1\nThe SQL being executed was: INSERT INTO `branch` (`name`, `address`, `owner`, `tel`, `fax`, `email`, `website`, `hotline`, `is_master`, `parent_id`) VALUES (\'fdsfdsf fsđsfd fds fsdf fsdf\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', NULL, NULL)\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Schema.php:628\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Command.php(794): yii\\db\\Schema->convertException(Object(PDOException), \'INSERT INTO `br...\')\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Schema.php(448): yii\\db\\Command->execute()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(457): yii\\db\\Schema->insert(\'branch\', Array)\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(427): yii\\db\\ActiveRecord->insertInternal(NULL)\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\BaseActiveRecord.php(593): yii\\db\\ActiveRecord->insert(true, NULL)\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(77): yii\\db\\BaseActiveRecord->save()\n#6 [internal function]: backend\\controllers\\BranchController->actionCreate()\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'create\', Array)\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/create\', Array)\n#11 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#12 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#13 {main}\r\nAdditional Information:\r\nArray\n(\n    [0] => HY000\n    [1] => 1366\n    [2] => Incorrect string value: \'\\xC4\\x91sfd ...\' for column \'name\' at row 1\n)\n'),(16,1,'yii\\db\\Exception',1459157723.8938,'[backend][/admin/branch/create]','exception \'PDOException\' with message \'SQLSTATE[HY000]: General error: 1366 Incorrect string value: \'\\xC4\\x91sfd ...\' for column \'name\' at row 1\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Command.php:784\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Command.php(784): PDOStatement->execute()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Schema.php(448): yii\\db\\Command->execute()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(457): yii\\db\\Schema->insert(\'branch\', Array)\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(427): yii\\db\\ActiveRecord->insertInternal(NULL)\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\BaseActiveRecord.php(593): yii\\db\\ActiveRecord->insert(true, NULL)\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(77): yii\\db\\BaseActiveRecord->save()\n#6 [internal function]: backend\\controllers\\BranchController->actionCreate()\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'create\', Array)\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/create\', Array)\n#11 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#12 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#13 {main}\n\nNext exception \'yii\\db\\Exception\' with message \'SQLSTATE[HY000]: General error: 1366 Incorrect string value: \'\\xC4\\x91sfd ...\' for column \'name\' at row 1\nThe SQL being executed was: INSERT INTO `branch` (`name`, `address`, `owner`, `tel`, `fax`, `email`, `website`, `hotline`, `is_master`, `parent_id`) VALUES (\'fdsfdsf fsđsfd fds fsdf fsdf\', \'\', \'\', \'\', \'\', \'\', \'\', \'\', NULL, NULL)\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Schema.php:628\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Command.php(794): yii\\db\\Schema->convertException(Object(PDOException), \'INSERT INTO `br...\')\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Schema.php(448): yii\\db\\Command->execute()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(457): yii\\db\\Schema->insert(\'branch\', Array)\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(427): yii\\db\\ActiveRecord->insertInternal(NULL)\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\BaseActiveRecord.php(593): yii\\db\\ActiveRecord->insert(true, NULL)\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(77): yii\\db\\BaseActiveRecord->save()\n#6 [internal function]: backend\\controllers\\BranchController->actionCreate()\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'create\', Array)\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/create\', Array)\n#11 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#12 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#13 {main}\r\nAdditional Information:\r\nArray\n(\n    [0] => HY000\n    [1] => 1366\n    [2] => Incorrect string value: \'\\xC4\\x91sfd ...\' for column \'name\' at row 1\n)\n'),(17,1,'yii\\base\\InvalidConfigException',1459181866.8255,'[backend][/admin/assets/pages/img/background/37.jpg]','exception \'yii\\base\\InvalidConfigException\' with message \'yii\\web\\Request::cookieValidationKey must be configured with a secret key.\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php:1225\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php(1207): yii\\web\\Request->loadCookies()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\common\\behaviors\\LocaleBehavior.php(39): yii\\web\\Request->getCookies()\n#2 [internal function]: common\\behaviors\\LocaleBehavior->beforeRequest(Object(yii\\base\\Event))\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Component.php(541): call_user_func(Array, Object(yii\\base\\Event))\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(372): yii\\base\\Component->trigger(\'beforeRequest\')\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#6 {main}'),(18,1,'yii\\base\\InvalidConfigException',1459182033.2009,'[backend][/admin/assets/pages/img/avatars/team3.jpg]','exception \'yii\\base\\InvalidConfigException\' with message \'yii\\web\\Request::cookieValidationKey must be configured with a secret key.\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php:1225\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php(1207): yii\\web\\Request->loadCookies()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\common\\behaviors\\LocaleBehavior.php(39): yii\\web\\Request->getCookies()\n#2 [internal function]: common\\behaviors\\LocaleBehavior->beforeRequest(Object(yii\\base\\Event))\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Component.php(541): call_user_func(Array, Object(yii\\base\\Event))\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(372): yii\\base\\Component->trigger(\'beforeRequest\')\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#6 {main}'),(19,1,'yii\\base\\InvalidConfigException',1459183554.9414,'[backend][/admin/debug/default/toolbar?tag=56f95fc19d914]','exception \'yii\\base\\InvalidConfigException\' with message \'yii\\web\\Request::cookieValidationKey must be configured with a secret key.\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php:1225\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php(1207): yii\\web\\Request->loadCookies()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\common\\behaviors\\LocaleBehavior.php(39): yii\\web\\Request->getCookies()\n#2 [internal function]: common\\behaviors\\LocaleBehavior->beforeRequest(Object(yii\\base\\Event))\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Component.php(541): call_user_func(Array, Object(yii\\base\\Event))\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(372): yii\\base\\Component->trigger(\'beforeRequest\')\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#6 {main}'),(20,1,'yii\\base\\InvalidConfigException',1459608780.1596,'[backend][/admin/assets/layouts/layout/img/avatar6.jpg]','exception \'yii\\base\\InvalidConfigException\' with message \'yii\\web\\Request::cookieValidationKey must be configured with a secret key.\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php:1225\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php(1207): yii\\web\\Request->loadCookies()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\common\\behaviors\\LocaleBehavior.php(39): yii\\web\\Request->getCookies()\n#2 [internal function]: common\\behaviors\\LocaleBehavior->beforeRequest(Object(yii\\base\\Event))\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Component.php(541): call_user_func(Array, Object(yii\\base\\Event))\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(372): yii\\base\\Component->trigger(\'beforeRequest\')\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#6 {main}'),(21,1,'yii\\base\\InvalidConfigException',1459610785.6792,'[backend][/admin/branch/]','exception \'yii\\base\\InvalidConfigException\' with message \'The class \'\\kartik\\editable\\Editable\' was not found and is required for GridView EditableColumn.\n\nPlease ensure you have installed the \'yii2-editable\' extension. To install, you can run this console command from your application root:\n\nphp composer.phar require kartik-v/yii2-editable: \"@dev\"\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\kartik-v\\yii2-krajee-base\\Config.php:120\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\kartik-v\\yii2-grid\\EditableColumn.php(73): kartik\\base\\Config::checkDependency(\'editable\\\\Editab...\', \'yii2-editable\', \'for GridView Ed...\')\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Object.php(107): kartik\\grid\\EditableColumn->init()\n#2 [internal function]: yii\\base\\Object->__construct(Array)\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\di\\Container.php(374): ReflectionClass->newInstanceArgs(Array)\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\di\\Container.php(153): yii\\di\\Container->build(\'kartik\\\\grid\\\\Edi...\', Array, Array)\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\BaseYii.php(344): yii\\di\\Container->get(\'kartik\\\\grid\\\\Edi...\', Array, Array)\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\grid\\GridView.php(531): yii\\BaseYii::createObject(Array)\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\grid\\GridView.php(275): yii\\grid\\GridView->initColumns()\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\kartik-v\\yii2-grid\\GridView.php(741): yii\\grid\\GridView->init()\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Object.php(107): kartik\\grid\\GridView->init()\n#10 [internal function]: yii\\base\\Object->__construct(Array)\n#11 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\di\\Container.php(374): ReflectionClass->newInstanceArgs(Array)\n#12 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\di\\Container.php(153): yii\\di\\Container->build(\'kartik\\\\grid\\\\Gri...\', Array, Array)\n#13 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\BaseYii.php(344): yii\\di\\Container->get(\'kartik\\\\grid\\\\Gri...\', Array, Array)\n#14 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Widget.php(97): yii\\BaseYii::createObject(Array)\n#15 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\views\\branch\\index.php(95): yii\\base\\Widget::widget(Array)\n#16 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(325): require(\'D:\\\\Working\\\\Me\\\\i...\')\n#17 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(247): yii\\base\\View->renderPhpFile(\'D:\\\\Working\\\\Me\\\\i...\', Array)\n#18 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(149): yii\\base\\View->renderFile(\'D:\\\\Working\\\\Me\\\\i...\', Array, Object(backend\\controllers\\BranchController))\n#19 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(377): yii\\base\\View->render(\'index\', Array, Object(backend\\controllers\\BranchController))\n#20 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(41): yii\\base\\Controller->render(\'index\', Array)\n#21 [internal function]: backend\\controllers\\BranchController->actionIndex()\n#22 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#23 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#24 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'\', Array)\n#25 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/\', Array)\n#26 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#27 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#28 {main}'),(22,1,'yii\\base\\InvalidConfigException',1459611250.8196,'[backend][/admin/branch/]','exception \'yii\\base\\InvalidConfigException\' with message \'The class \'\\kartik\\color\\ColorInput\' was not found and is required for filtering the grid as per your setup.\n\nPlease ensure you have installed one of \'yii2-widgets\' OR \'yii2-widget-colorinput\' extensions. To install, you can run this console command from your application root:\n\nphp composer.phar require kartik-v/yii2-widgets: \"@dev\"\n\n--- OR ---\n\nphp composer.phar require kartik-v/yii2-widget-colorinput: \"@dev\"\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\kartik-v\\yii2-krajee-base\\Config.php:120\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\kartik-v\\yii2-krajee-base\\Config.php(200): kartik\\base\\Config::checkDependency(\'\\\\kartik\\\\color\\\\C...\', Array, \'for filtering t...\')\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\kartik-v\\yii2-grid\\ColumnTrait.php(173): kartik\\base\\Config::validateInputWidget(\'\\\\kartik\\\\color\\\\C...\', \'for filtering t...\')\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\kartik-v\\yii2-grid\\DataColumn.php(317): kartik\\grid\\DataColumn->checkValidFilters()\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Object.php(107): kartik\\grid\\DataColumn->init()\n#4 [internal function]: yii\\base\\Object->__construct(Array)\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\di\\Container.php(374): ReflectionClass->newInstanceArgs(Array)\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\di\\Container.php(153): yii\\di\\Container->build(\'kartik\\\\grid\\\\Dat...\', Array, Array)\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\BaseYii.php(344): yii\\di\\Container->get(\'kartik\\\\grid\\\\Dat...\', Array, Array)\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\grid\\GridView.php(531): yii\\BaseYii::createObject(Array)\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\grid\\GridView.php(275): yii\\grid\\GridView->initColumns()\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\kartik-v\\yii2-grid\\GridView.php(741): yii\\grid\\GridView->init()\n#11 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Object.php(107): kartik\\grid\\GridView->init()\n#12 [internal function]: yii\\base\\Object->__construct(Array)\n#13 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\di\\Container.php(374): ReflectionClass->newInstanceArgs(Array)\n#14 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\di\\Container.php(153): yii\\di\\Container->build(\'kartik\\\\grid\\\\Gri...\', Array, Array)\n#15 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\BaseYii.php(344): yii\\di\\Container->get(\'kartik\\\\grid\\\\Gri...\', Array, Array)\n#16 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Widget.php(97): yii\\BaseYii::createObject(Array)\n#17 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\views\\branch\\index.php(95): yii\\base\\Widget::widget(Array)\n#18 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(325): require(\'D:\\\\Working\\\\Me\\\\i...\')\n#19 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(247): yii\\base\\View->renderPhpFile(\'D:\\\\Working\\\\Me\\\\i...\', Array)\n#20 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(149): yii\\base\\View->renderFile(\'D:\\\\Working\\\\Me\\\\i...\', Array, Object(backend\\controllers\\BranchController))\n#21 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(377): yii\\base\\View->render(\'index\', Array, Object(backend\\controllers\\BranchController))\n#22 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(41): yii\\base\\Controller->render(\'index\', Array)\n#23 [internal function]: backend\\controllers\\BranchController->actionIndex()\n#24 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#25 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#26 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'\', Array)\n#27 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/\', Array)\n#28 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#29 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#30 {main}'),(23,1,'yii\\base\\InvalidConfigException',1459611274.0936,'[backend][/admin/branch/]','exception \'yii\\base\\InvalidConfigException\' with message \'The class \'\\kartik\\mpdf\\Pdf\' was not found and is required for PDF export functionality. To include PDF export, follow the install steps below. If you do not need PDF export functionality, do not include \'PDF\' as a format in the \'export\' property. You can otherwise set \'export\' to \'false\' to disable all export functionality.\n\nPlease ensure you have installed the \'yii2-mpdf\' extension. To install, you can run this console command from your application root:\n\nphp composer.phar require kartik-v/yii2-mpdf: \"@dev\"\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\kartik-v\\yii2-krajee-base\\Config.php:120\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\kartik-v\\yii2-grid\\GridView.php(759): kartik\\base\\Config::checkDependency(\'mpdf\\\\Pdf\', \'yii2-mpdf\', \'for PDF export ...\')\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Widget.php(98): kartik\\grid\\GridView->run()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\views\\branch\\index.php(94): yii\\base\\Widget::widget(Array)\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(325): require(\'D:\\\\Working\\\\Me\\\\i...\')\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(247): yii\\base\\View->renderPhpFile(\'D:\\\\Working\\\\Me\\\\i...\', Array)\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(149): yii\\base\\View->renderFile(\'D:\\\\Working\\\\Me\\\\i...\', Array, Object(backend\\controllers\\BranchController))\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(377): yii\\base\\View->render(\'index\', Array, Object(backend\\controllers\\BranchController))\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(41): yii\\base\\Controller->render(\'index\', Array)\n#8 [internal function]: backend\\controllers\\BranchController->actionIndex()\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#11 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'\', Array)\n#12 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/\', Array)\n#13 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#14 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#15 {main}'),(24,1,'yii\\base\\InvalidConfigException',1459611282.2174,'[backend][/admin/branch/]','exception \'yii\\base\\InvalidConfigException\' with message \'The class \'\\kartik\\mpdf\\Pdf\' was not found and is required for PDF export functionality. To include PDF export, follow the install steps below. If you do not need PDF export functionality, do not include \'PDF\' as a format in the \'export\' property. You can otherwise set \'export\' to \'false\' to disable all export functionality.\n\nPlease ensure you have installed the \'yii2-mpdf\' extension. To install, you can run this console command from your application root:\n\nphp composer.phar require kartik-v/yii2-mpdf: \"@dev\"\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\kartik-v\\yii2-krajee-base\\Config.php:120\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\kartik-v\\yii2-grid\\GridView.php(759): kartik\\base\\Config::checkDependency(\'mpdf\\\\Pdf\', \'yii2-mpdf\', \'for PDF export ...\')\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Widget.php(98): kartik\\grid\\GridView->run()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\views\\branch\\index.php(94): yii\\base\\Widget::widget(Array)\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(325): require(\'D:\\\\Working\\\\Me\\\\i...\')\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(247): yii\\base\\View->renderPhpFile(\'D:\\\\Working\\\\Me\\\\i...\', Array)\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(149): yii\\base\\View->renderFile(\'D:\\\\Working\\\\Me\\\\i...\', Array, Object(backend\\controllers\\BranchController))\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(377): yii\\base\\View->render(\'index\', Array, Object(backend\\controllers\\BranchController))\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(41): yii\\base\\Controller->render(\'index\', Array)\n#8 [internal function]: backend\\controllers\\BranchController->actionIndex()\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#11 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'\', Array)\n#12 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/\', Array)\n#13 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#14 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#15 {main}'),(25,1,'yii\\base\\InvalidConfigException',1459611300.7505,'[backend][/admin/branch/]','exception \'yii\\base\\InvalidConfigException\' with message \'The class \'\\kartik\\color\\ColorInput\' was not found and is required for filtering the grid as per your setup.\n\nPlease ensure you have installed one of \'yii2-widgets\' OR \'yii2-widget-colorinput\' extensions. To install, you can run this console command from your application root:\n\nphp composer.phar require kartik-v/yii2-widgets: \"@dev\"\n\n--- OR ---\n\nphp composer.phar require kartik-v/yii2-widget-colorinput: \"@dev\"\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\kartik-v\\yii2-krajee-base\\Config.php:120\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\kartik-v\\yii2-krajee-base\\Config.php(200): kartik\\base\\Config::checkDependency(\'\\\\kartik\\\\color\\\\C...\', Array, \'for filtering t...\')\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\kartik-v\\yii2-grid\\ColumnTrait.php(173): kartik\\base\\Config::validateInputWidget(\'\\\\kartik\\\\color\\\\C...\', \'for filtering t...\')\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\kartik-v\\yii2-grid\\DataColumn.php(317): kartik\\grid\\DataColumn->checkValidFilters()\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Object.php(107): kartik\\grid\\DataColumn->init()\n#4 [internal function]: yii\\base\\Object->__construct(Array)\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\di\\Container.php(374): ReflectionClass->newInstanceArgs(Array)\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\di\\Container.php(153): yii\\di\\Container->build(\'kartik\\\\grid\\\\Dat...\', Array, Array)\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\BaseYii.php(344): yii\\di\\Container->get(\'kartik\\\\grid\\\\Dat...\', Array, Array)\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\grid\\GridView.php(531): yii\\BaseYii::createObject(Array)\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\grid\\GridView.php(275): yii\\grid\\GridView->initColumns()\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\kartik-v\\yii2-grid\\GridView.php(741): yii\\grid\\GridView->init()\n#11 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Object.php(107): kartik\\grid\\GridView->init()\n#12 [internal function]: yii\\base\\Object->__construct(Array)\n#13 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\di\\Container.php(374): ReflectionClass->newInstanceArgs(Array)\n#14 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\di\\Container.php(153): yii\\di\\Container->build(\'kartik\\\\grid\\\\Gri...\', Array, Array)\n#15 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\BaseYii.php(344): yii\\di\\Container->get(\'kartik\\\\grid\\\\Gri...\', Array, Array)\n#16 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Widget.php(97): yii\\BaseYii::createObject(Array)\n#17 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\views\\branch\\index.php(95): yii\\base\\Widget::widget(Array)\n#18 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(325): require(\'D:\\\\Working\\\\Me\\\\i...\')\n#19 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(247): yii\\base\\View->renderPhpFile(\'D:\\\\Working\\\\Me\\\\i...\', Array)\n#20 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(149): yii\\base\\View->renderFile(\'D:\\\\Working\\\\Me\\\\i...\', Array, Object(backend\\controllers\\BranchController))\n#21 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(377): yii\\base\\View->render(\'index\', Array, Object(backend\\controllers\\BranchController))\n#22 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(41): yii\\base\\Controller->render(\'index\', Array)\n#23 [internal function]: backend\\controllers\\BranchController->actionIndex()\n#24 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#25 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#26 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'\', Array)\n#27 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/\', Array)\n#28 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#29 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#30 {main}'),(26,1,'yii\\base\\ErrorException:4',1459663062.1441,'[backend][/admin/branch/index?BranchSearch%5Bname%5D=&BranchSearch%5Bis_master%5D=&_tog1149016d=page]','exception \'yii\\base\\ErrorException\' with message \'syntax error, unexpected \']\'\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\views\\branch\\index.php:77\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(149): yii\\base\\View->renderFile()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(377): yii\\base\\View->render()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(41): yii\\base\\Controller->render()\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): backend\\controllers\\BranchController->actionIndex()\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): ::call_user_func_array:{D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php:55}()\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams()\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction()\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction()\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest()\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#10 {main}'),(27,1,'yii\\base\\InvalidConfigException',1459663508.8466,'[backend][/admin/assets/layouts/layout/img/avatar7.jpg]','exception \'yii\\base\\InvalidConfigException\' with message \'yii\\web\\Request::cookieValidationKey must be configured with a secret key.\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php:1225\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php(1207): yii\\web\\Request->loadCookies()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\common\\behaviors\\LocaleBehavior.php(39): yii\\web\\Request->getCookies()\n#2 [internal function]: common\\behaviors\\LocaleBehavior->beforeRequest(Object(yii\\base\\Event))\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Component.php(541): call_user_func(Array, Object(yii\\base\\Event))\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(372): yii\\base\\Component->trigger(\'beforeRequest\')\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#6 {main}'),(28,1,'yii\\base\\InvalidConfigException',1459663508.8943,'[backend][/admin/assets/layouts/layout/img/avatar8.jpg]','exception \'yii\\base\\InvalidConfigException\' with message \'yii\\web\\Request::cookieValidationKey must be configured with a secret key.\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php:1225\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php(1207): yii\\web\\Request->loadCookies()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\common\\behaviors\\LocaleBehavior.php(39): yii\\web\\Request->getCookies()\n#2 [internal function]: common\\behaviors\\LocaleBehavior->beforeRequest(Object(yii\\base\\Event))\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Component.php(541): call_user_func(Array, Object(yii\\base\\Event))\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(372): yii\\base\\Component->trigger(\'beforeRequest\')\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#6 {main}'),(29,1,'yii\\base\\InvalidConfigException',1459664625.7935,'[backend][/admin/debug/default/toolbar?tag=5700b6ec59bd1]','exception \'yii\\base\\InvalidConfigException\' with message \'yii\\web\\Request::cookieValidationKey must be configured with a secret key.\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php:1225\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php(1207): yii\\web\\Request->loadCookies()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\common\\behaviors\\LocaleBehavior.php(39): yii\\web\\Request->getCookies()\n#2 [internal function]: common\\behaviors\\LocaleBehavior->beforeRequest(Object(yii\\base\\Event))\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Component.php(541): call_user_func(Array, Object(yii\\base\\Event))\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(372): yii\\base\\Component->trigger(\'beforeRequest\')\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#6 {main}'),(30,1,'yii\\base\\ErrorException:4',1459665091.1201,'[backend][/admin/branch/]','exception \'yii\\base\\ErrorException\' with message \'syntax error, unexpected \'<\'\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\views\\branch\\index.php:19\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(149): yii\\base\\View->renderFile()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(377): yii\\base\\View->render()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(41): yii\\base\\Controller->render()\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): backend\\controllers\\BranchController->actionIndex()\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): ::call_user_func_array:{D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php:55}()\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams()\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction()\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction()\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest()\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#10 {main}'),(31,1,'yii\\base\\UnknownMethodException',1459672775.5992,'[backend][/admin/branch/create]','exception \'yii\\base\\UnknownMethodException\' with message \'Calling unknown method: yii\\bootstrap\\ActiveField::template()\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Component.php:285\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\views\\branch\\_form.php(18): yii\\base\\Component->__call(\'template\', Array)\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\views\\branch\\_form.php(18): yii\\bootstrap\\ActiveField->template(\'<label class=\"c...\')\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(325): require(\'D:\\\\Working\\\\Me\\\\i...\')\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(247): yii\\base\\View->renderPhpFile(\'D:\\\\Working\\\\Me\\\\i...\', Array)\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\View.php(210): yii\\base\\View->renderFile(\'D:\\\\Working\\\\Me\\\\i...\', Array, Object(backend\\controllers\\BranchController))\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Controller.php(47): yii\\web\\View->renderAjax(\'_form\', Array, Object(backend\\controllers\\BranchController))\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(91): yii\\web\\Controller->renderAjax(\'_form\', Array)\n#7 [internal function]: backend\\controllers\\BranchController->actionCreate()\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'create\', Array)\n#11 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/create\', Array)\n#12 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#13 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#14 {main}'),(32,1,'yii\\base\\UnknownMethodException',1459672793.2055,'[backend][/admin/branch/create]','exception \'yii\\base\\UnknownMethodException\' with message \'Calling unknown method: yii\\bootstrap\\ActiveField::template()\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Component.php:285\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\views\\branch\\_form.php(18): yii\\base\\Component->__call(\'template\', Array)\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\views\\branch\\_form.php(18): yii\\bootstrap\\ActiveField->template(\'<label class=\"c...\')\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(325): require(\'D:\\\\Working\\\\Me\\\\i...\')\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(247): yii\\base\\View->renderPhpFile(\'D:\\\\Working\\\\Me\\\\i...\', Array)\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\View.php(210): yii\\base\\View->renderFile(\'D:\\\\Working\\\\Me\\\\i...\', Array, Object(backend\\controllers\\BranchController))\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Controller.php(47): yii\\web\\View->renderAjax(\'_form\', Array, Object(backend\\controllers\\BranchController))\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(91): yii\\web\\Controller->renderAjax(\'_form\', Array)\n#7 [internal function]: backend\\controllers\\BranchController->actionCreate()\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'create\', Array)\n#11 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/create\', Array)\n#12 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#13 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#14 {main}'),(33,1,'yii\\base\\InvalidParamException',1459673181.3709,'[backend][/admin/branch/create]','exception \'yii\\base\\InvalidParamException\' with message \'Attribute name must contain word characters only.\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\helpers\\BaseHtml.php:2027\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\helpers\\BaseHtml.php(1244): yii\\helpers\\BaseHtml::getAttributeName(\'\')\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\helpers\\BaseHtml.php(1274): yii\\helpers\\BaseHtml::normalizeMaxLength(Object(common\\models\\Branch), \'\', Array)\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\widgets\\ActiveField.php(364): yii\\helpers\\BaseHtml::activeTextInput(Object(common\\models\\Branch), \'\', Array)\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\views\\branch\\_form.php(16): yii\\widgets\\ActiveField->textInput(Array)\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(325): require(\'D:\\\\Working\\\\Me\\\\i...\')\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(247): yii\\base\\View->renderPhpFile(\'D:\\\\Working\\\\Me\\\\i...\', Array)\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\View.php(210): yii\\base\\View->renderFile(\'D:\\\\Working\\\\Me\\\\i...\', Array, Object(backend\\controllers\\BranchController))\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Controller.php(47): yii\\web\\View->renderAjax(\'_form\', Array, Object(backend\\controllers\\BranchController))\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(91): yii\\web\\Controller->renderAjax(\'_form\', Array)\n#9 [internal function]: backend\\controllers\\BranchController->actionCreate()\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#11 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#12 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'create\', Array)\n#13 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/create\', Array)\n#14 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#15 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#16 {main}'),(34,1,'yii\\base\\InvalidParamException',1459673197.6192,'[backend][/admin/branch/create]','exception \'yii\\base\\InvalidParamException\' with message \'Attribute name must contain word characters only.\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\helpers\\BaseHtml.php:2027\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\helpers\\BaseHtml.php(1244): yii\\helpers\\BaseHtml::getAttributeName(\'\')\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\helpers\\BaseHtml.php(1274): yii\\helpers\\BaseHtml::normalizeMaxLength(Object(common\\models\\Branch), \'\', Array)\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\widgets\\ActiveField.php(364): yii\\helpers\\BaseHtml::activeTextInput(Object(common\\models\\Branch), \'\', Array)\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\views\\branch\\_form.php(16): yii\\widgets\\ActiveField->textInput(Array)\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(325): require(\'D:\\\\Working\\\\Me\\\\i...\')\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(247): yii\\base\\View->renderPhpFile(\'D:\\\\Working\\\\Me\\\\i...\', Array)\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\View.php(210): yii\\base\\View->renderFile(\'D:\\\\Working\\\\Me\\\\i...\', Array, Object(backend\\controllers\\BranchController))\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Controller.php(47): yii\\web\\View->renderAjax(\'_form\', Array, Object(backend\\controllers\\BranchController))\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(91): yii\\web\\Controller->renderAjax(\'_form\', Array)\n#9 [internal function]: backend\\controllers\\BranchController->actionCreate()\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#11 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#12 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'create\', Array)\n#13 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/create\', Array)\n#14 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#15 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#16 {main}'),(35,1,'yii\\base\\InvalidParamException',1459673204.8886,'[backend][/admin/branch/create]','exception \'yii\\base\\InvalidParamException\' with message \'Attribute name must contain word characters only.\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\helpers\\BaseHtml.php:2027\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\helpers\\BaseHtml.php(1244): yii\\helpers\\BaseHtml::getAttributeName(\'\')\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\helpers\\BaseHtml.php(1274): yii\\helpers\\BaseHtml::normalizeMaxLength(Object(common\\models\\Branch), \'\', Array)\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\widgets\\ActiveField.php(364): yii\\helpers\\BaseHtml::activeTextInput(Object(common\\models\\Branch), \'\', Array)\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\views\\branch\\_form.php(16): yii\\widgets\\ActiveField->textInput(Array)\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(325): require(\'D:\\\\Working\\\\Me\\\\i...\')\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(247): yii\\base\\View->renderPhpFile(\'D:\\\\Working\\\\Me\\\\i...\', Array)\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\View.php(210): yii\\base\\View->renderFile(\'D:\\\\Working\\\\Me\\\\i...\', Array, Object(backend\\controllers\\BranchController))\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Controller.php(47): yii\\web\\View->renderAjax(\'_form\', Array, Object(backend\\controllers\\BranchController))\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(91): yii\\web\\Controller->renderAjax(\'_form\', Array)\n#9 [internal function]: backend\\controllers\\BranchController->actionCreate()\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#11 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#12 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'create\', Array)\n#13 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/create\', Array)\n#14 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#15 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#16 {main}'),(36,1,'yii\\base\\InvalidConfigException',1459673966.2429,'[backend][/admin/debug/default/toolbar?tag=5700db6b833f2]','exception \'yii\\base\\InvalidConfigException\' with message \'yii\\web\\Request::cookieValidationKey must be configured with a secret key.\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php:1225\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php(1207): yii\\web\\Request->loadCookies()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\common\\behaviors\\LocaleBehavior.php(39): yii\\web\\Request->getCookies()\n#2 [internal function]: common\\behaviors\\LocaleBehavior->beforeRequest(Object(yii\\base\\Event))\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Component.php(541): call_user_func(Array, Object(yii\\base\\Event))\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(372): yii\\base\\Component->trigger(\'beforeRequest\')\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#6 {main}'),(37,1,'yii\\base\\InvalidConfigException',1459674761.2796,'[backend][/admin/assets/layouts/layout/img/avatar9.jpg]','exception \'yii\\base\\InvalidConfigException\' with message \'yii\\web\\Request::cookieValidationKey must be configured with a secret key.\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php:1225\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php(1207): yii\\web\\Request->loadCookies()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\common\\behaviors\\LocaleBehavior.php(39): yii\\web\\Request->getCookies()\n#2 [internal function]: common\\behaviors\\LocaleBehavior->beforeRequest(Object(yii\\base\\Event))\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Component.php(541): call_user_func(Array, Object(yii\\base\\Event))\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(372): yii\\base\\Component->trigger(\'beforeRequest\')\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#6 {main}'),(38,1,'yii\\db\\Exception',1459674884.3121,'[backend][/admin/branch/create]','exception \'PDOException\' with message \'SQLSTATE[HY000]: General error: 1366 Incorrect string value: \'\\xE1\\xBA\\xB7ng ...\' for column \'name\' at row 1\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Command.php:784\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Command.php(784): PDOStatement->execute()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Schema.php(448): yii\\db\\Command->execute()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(457): yii\\db\\Schema->insert(\'branch\', Array)\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(427): yii\\db\\ActiveRecord->insertInternal(NULL)\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\BaseActiveRecord.php(593): yii\\db\\ActiveRecord->insert(true, NULL)\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(78): yii\\db\\BaseActiveRecord->save()\n#6 [internal function]: backend\\controllers\\BranchController->actionCreate()\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'create\', Array)\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/create\', Array)\n#11 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#12 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#13 {main}\n\nNext exception \'yii\\db\\Exception\' with message \'SQLSTATE[HY000]: General error: 1366 Incorrect string value: \'\\xE1\\xBA\\xB7ng ...\' for column \'name\' at row 1\nThe SQL being executed was: INSERT INTO `branch` (`name`, `address`, `owner`, `tel`, `fax`, `email`, `website`, `hotline`, `is_master`, `parent_id`) VALUES (\'Công ty quà tặng pha lê\', \'1B Lý Chính Thắng, Quận 3, Hồ Chí Minh\', \'\', \'+84963556467\', \'\', \'\', \'\', \'\', NULL, NULL)\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Schema.php:628\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Command.php(794): yii\\db\\Schema->convertException(Object(PDOException), \'INSERT INTO `br...\')\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Schema.php(448): yii\\db\\Command->execute()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(457): yii\\db\\Schema->insert(\'branch\', Array)\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(427): yii\\db\\ActiveRecord->insertInternal(NULL)\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\BaseActiveRecord.php(593): yii\\db\\ActiveRecord->insert(true, NULL)\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(78): yii\\db\\BaseActiveRecord->save()\n#6 [internal function]: backend\\controllers\\BranchController->actionCreate()\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'create\', Array)\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/create\', Array)\n#11 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#12 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#13 {main}\r\nAdditional Information:\r\nArray\n(\n    [0] => HY000\n    [1] => 1366\n    [2] => Incorrect string value: \'\\xE1\\xBA\\xB7ng ...\' for column \'name\' at row 1\n)\n'),(39,1,'yii\\db\\Exception',1459674884.5487,'[backend][/admin/branch/create]','exception \'PDOException\' with message \'SQLSTATE[HY000]: General error: 1366 Incorrect string value: \'\\xE1\\xBA\\xB7ng ...\' for column \'name\' at row 1\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Command.php:784\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Command.php(784): PDOStatement->execute()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Schema.php(448): yii\\db\\Command->execute()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(457): yii\\db\\Schema->insert(\'branch\', Array)\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(427): yii\\db\\ActiveRecord->insertInternal(NULL)\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\BaseActiveRecord.php(593): yii\\db\\ActiveRecord->insert(true, NULL)\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(78): yii\\db\\BaseActiveRecord->save()\n#6 [internal function]: backend\\controllers\\BranchController->actionCreate()\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'create\', Array)\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/create\', Array)\n#11 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#12 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#13 {main}\n\nNext exception \'yii\\db\\Exception\' with message \'SQLSTATE[HY000]: General error: 1366 Incorrect string value: \'\\xE1\\xBA\\xB7ng ...\' for column \'name\' at row 1\nThe SQL being executed was: INSERT INTO `branch` (`name`, `address`, `owner`, `tel`, `fax`, `email`, `website`, `hotline`, `is_master`, `parent_id`) VALUES (\'Công ty quà tặng pha lê\', \'1B Lý Chính Thắng, Quận 3, Hồ Chí Minh\', \'\', \'+84963556467\', \'\', \'\', \'\', \'\', NULL, NULL)\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Schema.php:628\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Command.php(794): yii\\db\\Schema->convertException(Object(PDOException), \'INSERT INTO `br...\')\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Schema.php(448): yii\\db\\Command->execute()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(457): yii\\db\\Schema->insert(\'branch\', Array)\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(427): yii\\db\\ActiveRecord->insertInternal(NULL)\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\BaseActiveRecord.php(593): yii\\db\\ActiveRecord->insert(true, NULL)\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(78): yii\\db\\BaseActiveRecord->save()\n#6 [internal function]: backend\\controllers\\BranchController->actionCreate()\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'create\', Array)\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/create\', Array)\n#11 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#12 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#13 {main}\r\nAdditional Information:\r\nArray\n(\n    [0] => HY000\n    [1] => 1366\n    [2] => Incorrect string value: \'\\xE1\\xBA\\xB7ng ...\' for column \'name\' at row 1\n)\n'),(40,1,'yii\\db\\Exception',1459674893.7292,'[backend][/admin/branch/create]','exception \'PDOException\' with message \'SQLSTATE[HY000]: General error: 1366 Incorrect string value: \'\\xE1\\xBA\\xB7ng ...\' for column \'name\' at row 1\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Command.php:784\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Command.php(784): PDOStatement->execute()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Schema.php(448): yii\\db\\Command->execute()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(457): yii\\db\\Schema->insert(\'branch\', Array)\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(427): yii\\db\\ActiveRecord->insertInternal(NULL)\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\BaseActiveRecord.php(593): yii\\db\\ActiveRecord->insert(true, NULL)\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(78): yii\\db\\BaseActiveRecord->save()\n#6 [internal function]: backend\\controllers\\BranchController->actionCreate()\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'create\', Array)\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/create\', Array)\n#11 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#12 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#13 {main}\n\nNext exception \'yii\\db\\Exception\' with message \'SQLSTATE[HY000]: General error: 1366 Incorrect string value: \'\\xE1\\xBA\\xB7ng ...\' for column \'name\' at row 1\nThe SQL being executed was: INSERT INTO `branch` (`name`, `address`, `owner`, `tel`, `fax`, `email`, `website`, `hotline`, `is_master`, `parent_id`) VALUES (\'Công ty quà tặng pha lê\', \'1B Lý Chính Thắng, Quận 3, Hồ Chí Minh\', \'\', \'+84963556467\', \'\', \'\', \'\', \'\', NULL, NULL)\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Schema.php:628\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Command.php(794): yii\\db\\Schema->convertException(Object(PDOException), \'INSERT INTO `br...\')\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Schema.php(448): yii\\db\\Command->execute()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(457): yii\\db\\Schema->insert(\'branch\', Array)\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(427): yii\\db\\ActiveRecord->insertInternal(NULL)\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\BaseActiveRecord.php(593): yii\\db\\ActiveRecord->insert(true, NULL)\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(78): yii\\db\\BaseActiveRecord->save()\n#6 [internal function]: backend\\controllers\\BranchController->actionCreate()\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'create\', Array)\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/create\', Array)\n#11 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#12 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#13 {main}\r\nAdditional Information:\r\nArray\n(\n    [0] => HY000\n    [1] => 1366\n    [2] => Incorrect string value: \'\\xE1\\xBA\\xB7ng ...\' for column \'name\' at row 1\n)\n'),(41,1,'yii\\db\\Exception',1459674932.6172,'[backend][/admin/branch/create]','exception \'PDOException\' with message \'SQLSTATE[HY000]: General error: 1366 Incorrect string value: \'\\xE1\\xBA\\xB7ng ...\' for column \'name\' at row 1\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Command.php:784\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Command.php(784): PDOStatement->execute()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Schema.php(448): yii\\db\\Command->execute()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(457): yii\\db\\Schema->insert(\'branch\', Array)\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(427): yii\\db\\ActiveRecord->insertInternal(NULL)\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\BaseActiveRecord.php(593): yii\\db\\ActiveRecord->insert(true, NULL)\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(78): yii\\db\\BaseActiveRecord->save()\n#6 [internal function]: backend\\controllers\\BranchController->actionCreate()\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'create\', Array)\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/create\', Array)\n#11 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#12 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#13 {main}\n\nNext exception \'yii\\db\\Exception\' with message \'SQLSTATE[HY000]: General error: 1366 Incorrect string value: \'\\xE1\\xBA\\xB7ng ...\' for column \'name\' at row 1\nThe SQL being executed was: INSERT INTO `branch` (`name`, `address`, `owner`, `tel`, `fax`, `email`, `website`, `hotline`, `is_master`, `parent_id`) VALUES (\'Công ty quà tặng pha lê\', \'1B Lý Chính Thắng, Quận 3, Hồ Chí Minh\', \'\', \'+84963556467\', \'\', \'\', \'\', \'\', NULL, NULL)\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Schema.php:628\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Command.php(794): yii\\db\\Schema->convertException(Object(PDOException), \'INSERT INTO `br...\')\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\Schema.php(448): yii\\db\\Command->execute()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(457): yii\\db\\Schema->insert(\'branch\', Array)\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\ActiveRecord.php(427): yii\\db\\ActiveRecord->insertInternal(NULL)\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\db\\BaseActiveRecord.php(593): yii\\db\\ActiveRecord->insert(true, NULL)\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(78): yii\\db\\BaseActiveRecord->save()\n#6 [internal function]: backend\\controllers\\BranchController->actionCreate()\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): call_user_func_array(Array, Array)\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams(Array)\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction(\'create\', Array)\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction(\'branch/create\', Array)\n#11 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#12 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#13 {main}\r\nAdditional Information:\r\nArray\n(\n    [0] => HY000\n    [1] => 1366\n    [2] => Incorrect string value: \'\\xE1\\xBA\\xB7ng ...\' for column \'name\' at row 1\n)\n'),(42,1,'yii\\base\\InvalidConfigException',1459675353.019,'[backend][/admin/assets/layouts/layout/img/avatar1.jpg]','exception \'yii\\base\\InvalidConfigException\' with message \'yii\\web\\Request::cookieValidationKey must be configured with a secret key.\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php:1225\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php(1207): yii\\web\\Request->loadCookies()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\common\\behaviors\\LocaleBehavior.php(39): yii\\web\\Request->getCookies()\n#2 [internal function]: common\\behaviors\\LocaleBehavior->beforeRequest(Object(yii\\base\\Event))\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Component.php(541): call_user_func(Array, Object(yii\\base\\Event))\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(372): yii\\base\\Component->trigger(\'beforeRequest\')\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#6 {main}'),(43,1,'yii\\base\\InvalidConfigException',1459675354.5697,'[backend][/admin/assets/layouts/layout/img/avatar7.jpg]','exception \'yii\\base\\InvalidConfigException\' with message \'yii\\web\\Request::cookieValidationKey must be configured with a secret key.\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php:1225\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php(1207): yii\\web\\Request->loadCookies()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\common\\behaviors\\LocaleBehavior.php(39): yii\\web\\Request->getCookies()\n#2 [internal function]: common\\behaviors\\LocaleBehavior->beforeRequest(Object(yii\\base\\Event))\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Component.php(541): call_user_func(Array, Object(yii\\base\\Event))\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(372): yii\\base\\Component->trigger(\'beforeRequest\')\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#6 {main}'),(44,1,'yii\\base\\InvalidConfigException',1459675354.9029,'[backend][/admin/assets/layouts/layout/img/avatar8.jpg]','exception \'yii\\base\\InvalidConfigException\' with message \'yii\\web\\Request::cookieValidationKey must be configured with a secret key.\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php:1225\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php(1207): yii\\web\\Request->loadCookies()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\common\\behaviors\\LocaleBehavior.php(39): yii\\web\\Request->getCookies()\n#2 [internal function]: common\\behaviors\\LocaleBehavior->beforeRequest(Object(yii\\base\\Event))\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Component.php(541): call_user_func(Array, Object(yii\\base\\Event))\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(372): yii\\base\\Component->trigger(\'beforeRequest\')\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#6 {main}'),(45,1,'yii\\base\\InvalidConfigException',1459675354.9695,'[backend][/admin/assets/layouts/layout/img/avatar11.jpg]','exception \'yii\\base\\InvalidConfigException\' with message \'yii\\web\\Request::cookieValidationKey must be configured with a secret key.\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php:1225\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php(1207): yii\\web\\Request->loadCookies()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\common\\behaviors\\LocaleBehavior.php(39): yii\\web\\Request->getCookies()\n#2 [internal function]: common\\behaviors\\LocaleBehavior->beforeRequest(Object(yii\\base\\Event))\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Component.php(541): call_user_func(Array, Object(yii\\base\\Event))\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(372): yii\\base\\Component->trigger(\'beforeRequest\')\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#6 {main}'),(46,1,'yii\\base\\ErrorException:1',1459676984.3015,'[backend][/admin/branch/index]','exception \'yii\\base\\ErrorException\' with message \'Class \'Breadcrumbs\' not found\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\views\\layouts\\metro.php:1484\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\View.php(247): yii\\base\\View->renderPhpFile()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(392): yii\\base\\View->renderFile()\n#2 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(378): yii\\base\\Controller->renderContent()\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\controllers\\BranchController.php(42): yii\\base\\Controller->render()\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): backend\\controllers\\BranchController->actionIndex()\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(55): ::call_user_func_array:{D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\InlineAction.php:55}()\n#6 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Controller.php(154): yii\\base\\InlineAction->runWithParams()\n#7 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Module.php(454): yii\\base\\Controller->runAction()\n#8 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Application.php(84): yii\\base\\Module->runAction()\n#9 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(375): yii\\web\\Application->handleRequest()\n#10 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#11 {main}'),(47,1,'yii\\base\\InvalidConfigException',1459676994.8942,'[backend][/admin/assets/layouts/layout/img/avatar11.jpg]','exception \'yii\\base\\InvalidConfigException\' with message \'yii\\web\\Request::cookieValidationKey must be configured with a secret key.\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php:1225\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php(1207): yii\\web\\Request->loadCookies()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\common\\behaviors\\LocaleBehavior.php(39): yii\\web\\Request->getCookies()\n#2 [internal function]: common\\behaviors\\LocaleBehavior->beforeRequest(Object(yii\\base\\Event))\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Component.php(541): call_user_func(Array, Object(yii\\base\\Event))\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(372): yii\\base\\Component->trigger(\'beforeRequest\')\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#6 {main}'),(48,1,'yii\\base\\InvalidConfigException',1459677318.107,'[backend][/admin/assets/layouts/layout3/img/avatar3.jpg]','exception \'yii\\base\\InvalidConfigException\' with message \'yii\\web\\Request::cookieValidationKey must be configured with a secret key.\' in D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php:1225\nStack trace:\n#0 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\web\\Request.php(1207): yii\\web\\Request->loadCookies()\n#1 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\common\\behaviors\\LocaleBehavior.php(39): yii\\web\\Request->getCookies()\n#2 [internal function]: common\\behaviors\\LocaleBehavior->beforeRequest(Object(yii\\base\\Event))\n#3 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Component.php(541): call_user_func(Array, Object(yii\\base\\Event))\n#4 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\vendor\\yiisoft\\yii2\\base\\Application.php(372): yii\\base\\Component->trigger(\'beforeRequest\')\n#5 D:\\Working\\Me\\iappservice\\base\\yii2-starter-kit\\backend\\web\\index.php(23): yii\\base\\Application->run()\n#6 {main}');
/*!40000 ALTER TABLE `system_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_rbac_migration`
--

DROP TABLE IF EXISTS `system_rbac_migration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_rbac_migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_rbac_migration`
--

LOCK TABLES `system_rbac_migration` WRITE;
/*!40000 ALTER TABLE `system_rbac_migration` DISABLE KEYS */;
INSERT INTO `system_rbac_migration` VALUES ('m000000_000000_base',1458980210),('m150625_214101_roles',1458980214),('m150625_215624_init_permissions',1458980214),('m151223_074604_edit_own_model',1458980214);
/*!40000 ALTER TABLE `system_rbac_migration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timeline_event`
--

DROP TABLE IF EXISTS `timeline_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timeline_event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `application` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `category` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `event` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timeline_event`
--

LOCK TABLES `timeline_event` WRITE;
/*!40000 ALTER TABLE `timeline_event` DISABLE KEYS */;
INSERT INTO `timeline_event` VALUES (1,'frontend','user','signup','{\"public_identity\":\"webmaster\",\"user_id\":1,\"created_at\":1458980207}',1458980207),(2,'frontend','user','signup','{\"public_identity\":\"manager\",\"user_id\":2,\"created_at\":1458980207}',1458980207),(3,'frontend','user','signup','{\"public_identity\":\"user\",\"user_id\":3,\"created_at\":1458980207}',1458980207);
/*!40000 ALTER TABLE `timeline_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `access_token` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `oauth_client` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `oauth_client_user_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '2',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `logged_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'webmaster','8kr2doUYFfYdIIFP5o2hgHgcwwmIwMhv','qVm7oK7qjHW2hI35Tpj0OP_GAg_g-75tk04dmf8E','$2y$13$8C7jpYREavUTnFNlmnyPQuun3zVpeZ/nQrqIBQpttjSd/W728Zmu2',NULL,NULL,'webmaster@example.com',2,1458980208,1459739854,1459739854),(2,'manager','P1zmcsXP9H30ut_9w6a45Fch7y5Ehykh','y3FiPywGktq9TV8GWC038E7DCint-TaoO5tfCyZR','$2y$13$jx1Dftz.ZnXpjclPfj0zjOCM3yQ3VFnz4bJUu5URFh8Zax86BeQO6',NULL,NULL,'manager@example.com',2,1458980209,1458980209,NULL),(3,'user','Opbe5RNIUtdCaKNeymNfsb4mN12WP5Gp','K4Qb0oZSP0SDtZb9DrLbOKzeuBF78ZXEW2gnuOX_','$2y$13$eGabshbNThfGGwcyjO2iBe/tEhitpiUbVFEWnAKZTMfTMXP2e38lq',NULL,NULL,'user@example.com',2,1458980210,1458980210,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_profile`
--

DROP TABLE IF EXISTS `user_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_profile` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `middlename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `avatar_path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `avatar_base_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locale` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `gender` smallint(1) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `fk_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_profile`
--

LOCK TABLES `user_profile` WRITE;
/*!40000 ALTER TABLE `user_profile` DISABLE KEYS */;
INSERT INTO `user_profile` VALUES (1,'John',NULL,'Doe',NULL,NULL,'en-US',NULL),(2,NULL,NULL,NULL,NULL,NULL,'en-US',NULL),(3,NULL,NULL,NULL,NULL,NULL,'en-US',NULL);
/*!40000 ALTER TABLE `user_profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_token`
--

DROP TABLE IF EXISTS `user_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `token` varchar(40) NOT NULL,
  `expire_at` int(11) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_token`
--

LOCK TABLES `user_token` WRITE;
/*!40000 ALTER TABLE `user_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widget_carousel`
--

DROP TABLE IF EXISTS `widget_carousel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widget_carousel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widget_carousel`
--

LOCK TABLES `widget_carousel` WRITE;
/*!40000 ALTER TABLE `widget_carousel` DISABLE KEYS */;
INSERT INTO `widget_carousel` VALUES (1,'index',1);
/*!40000 ALTER TABLE `widget_carousel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widget_carousel_item`
--

DROP TABLE IF EXISTS `widget_carousel_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widget_carousel_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `carousel_id` int(11) NOT NULL,
  `base_url` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `caption` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `order` int(11) DEFAULT '0',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_item_carousel` (`carousel_id`),
  CONSTRAINT `fk_item_carousel` FOREIGN KEY (`carousel_id`) REFERENCES `widget_carousel` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widget_carousel_item`
--

LOCK TABLES `widget_carousel_item` WRITE;
/*!40000 ALTER TABLE `widget_carousel_item` DISABLE KEYS */;
INSERT INTO `widget_carousel_item` VALUES (1,1,'http://base.dev','img/yii2-starter-kit.gif','image/gif','/',NULL,1,0,NULL,NULL);
/*!40000 ALTER TABLE `widget_carousel_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widget_menu`
--

DROP TABLE IF EXISTS `widget_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widget_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `items` text COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widget_menu`
--

LOCK TABLES `widget_menu` WRITE;
/*!40000 ALTER TABLE `widget_menu` DISABLE KEYS */;
INSERT INTO `widget_menu` VALUES (1,'frontend-index','Frontend index menu','[\n    {\n        \"label\": \"Get started with Yii2\",\n        \"url\": \"http://www.yiiframework.com\",\n        \"options\": {\n            \"tag\": \"span\"\n        },\n        \"template\": \"<a href=\\\"{url}\\\" class=\\\"btn btn-lg btn-success\\\">{label}</a>\"\n    },\n    {\n        \"label\": \"Yii2 Starter Kit on GitHub\",\n        \"url\": \"https://github.com/trntv/yii2-starter-kit\",\n        \"options\": {\n            \"tag\": \"span\"\n        },\n        \"template\": \"<a href=\\\"{url}\\\" class=\\\"btn btn-lg btn-primary\\\">{label}</a>\"\n    },\n    {\n        \"label\": \"Find a bug?\",\n        \"url\": \"https://github.com/trntv/yii2-starter-kit/issues\",\n        \"options\": {\n            \"tag\": \"span\"\n        },\n        \"template\": \"<a href=\\\"{url}\\\" class=\\\"btn btn-lg btn-danger\\\">{label}</a>\"\n    }\n]',1);
/*!40000 ALTER TABLE `widget_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widget_text`
--

DROP TABLE IF EXISTS `widget_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widget_text` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_widget_text_key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widget_text`
--

LOCK TABLES `widget_text` WRITE;
/*!40000 ALTER TABLE `widget_text` DISABLE KEYS */;
INSERT INTO `widget_text` VALUES (1,'backend_welcome','Welcome to backend','<p>Welcome to Yii2 Starter Kit Dashboard</p>',1,1458980210,1458980210),(2,'ads-example','Google Ads Example Block','<div class=\"lead\">\r\n                <script async src=\"//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js\"></script>\r\n                <ins class=\"adsbygoogle\"\r\n                     style=\"display:block\"\r\n                     data-ad-client=\"ca-pub-9505937224921657\"\r\n                     data-ad-slot=\"2264361777\"\r\n                     data-ad-format=\"auto\"></ins>\r\n                <script>\r\n                (adsbygoogle = window.adsbygoogle || []).push({});\r\n                </script>\r\n            </div>',0,1458980210,1458980851),(3,'chen-quang-cao','Chen quang cao google','<script>\r\n    alert(1);\r\n</script>',1,1458982406,1458982406);
/*!40000 ALTER TABLE `widget_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'base'
--

--
-- Dumping routines for database 'base'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-04-04 10:34:08
